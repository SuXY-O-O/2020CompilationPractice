#include "Error.h"

vector<Error* > ErrorTable::errors;