﻿#include "Tables.h"
map<string, int> FunctionTable::name_to_return_type;